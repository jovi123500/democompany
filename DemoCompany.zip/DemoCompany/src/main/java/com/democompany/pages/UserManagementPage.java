package com.democompany.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.democompany.utilities.PageUtility;

public class UserManagementPage extends PageUtility
{
	WebDriver driver;
	public UserManagementPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBys(
	@FindBy(xpath="//li[@class='treeview  active']//ul[@class='treeview-menu menu-open']//span"))
	List<WebElement> userManagementPageOptions;
	@FindBy(xpath="//section[@class='sidebar']/ul/li[2]/ul/li[1]/a")
	WebElement users;
	@FindBy(xpath="//section[@class='sidebar']/ul/li[2]/ul/li[2]/a")
	WebElement roles;
	
	public UsersPage ClickOnUserPage()
	{
	for(int i=0;i<userManagementPageOptions.size();i++)
	{
		if(userManagementPageOptions.get(i).getText().equalsIgnoreCase("Users"))
		{
			clickOnElement(users);
		}
		}
		return new UsersPage(driver);
	}
	
	public RolesPage ClickOnRolesPage()
	{
	for(int i=0;i<userManagementPageOptions.size();i++)
	{
		if(userManagementPageOptions.get(i).getText().equalsIgnoreCase("Roles"))
		{
			clickOnElement(roles);
		}
		}
		return new RolesPage(driver);
	}
	
	public SalescommissionPage clickOnSalesPage()
	{
		sleep(2000);
		for(int i=0;i<userManagementPageOptions.size();i++) {
			if(userManagementPageOptions.get(i).getText().equalsIgnoreCase("Sales Commission Agents"))
			{
				clickOnElement(userManagementPageOptions.get(i));
			}
			}
		
		return new SalescommissionPage(driver); 
	}
}
