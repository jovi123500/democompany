package com.democompany.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.democompany.utilities.PageUtility;


public class HomePage extends PageUtility
{
	WebDriver driver;
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//section[@class='content-header']//h1")
	WebElement userAccountName;
	@FindBy(xpath="//button[@class='btn btn-default btn-sm']")
	WebElement handletour;
	@FindBy(xpath="//a[text()='Sign Out']")
	WebElement signout;
	
	@FindBy(xpath="//ul[@class='sidebar-menu']//a//span[@class='title']")
	WebElement userManagement;
	
	
	public HomePage clickOnlogout()
	{
		clickOnElement(signout);
		return new HomePage(driver);
	}
	public String getUserName() 
	{
		String result=getElementText(userAccountName);
		return result;
	}
	
	public UserManagementPage clickOnUserManagement() 
	{
		clickOnElement(userManagement);
		return new UserManagementPage(driver); 
	}
	public void handleEndTour()
	{
		clickOnElement(handletour);
	}
	
	
}
