package com.democompany.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.democompany.utilities.PageUtility;

public class AddRolePage extends PageUtility
{
	WebDriver driver;
	public AddRolePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(xpath="//input[@id='name']")
	WebElement rollname;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[3][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionUser;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[4][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionRoles;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[5][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionSupplier;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[6][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionCustomer;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[7][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionProduct;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[8][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionPurchaseStock;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[9][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionSell;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[10][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionBrand;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[11][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionTaxRate;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[12][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> Unit;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[13][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionCategory;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[14][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionReport;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[15][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionSetting;
	
	@FindBys(@FindBy(xpath = "//form[@id='role_add_form']//div[17][@class='row check_group']//div[@class='icheckbox_square-blue']//ins"))
	List<WebElement> permissionAccount;
	
	@FindBy(xpath="//button[@class='btn btn-primary pull-right']")
	WebElement saveButton;

	
	public void enterRolename(String r)
	{
		enterText(rollname,r);
	}
	
	

	public void clickOnPermissionUser(String value) 
	{
		for (int i = 0; i < permissionUser.size(); i++) 
		{
			if (permissionUser.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionUser.get(i).click();
			}
		}
	}

	public void clickOnPermissionRoles(String value)
	{
		for (int i = 0; i < permissionRoles.size(); i++) 
		{
			if (permissionRoles.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionRoles.get(i).click();
			}
		}
	}

	public void clickOnPermissionSupplier(String value)
	{
		for (int i = 0; i < permissionSupplier.size(); i++) 
		{
			if (permissionSupplier.get(i).getText().equalsIgnoreCase(value))
			{
				permissionSupplier.get(i).click();
			}
		}
	}
	public void clickOnPermissionCustomer(String value) 
		{
			for (int i = 0; i < permissionCustomer.size(); i++)
			{
				if (permissionCustomer.get(i).getText().equalsIgnoreCase(value)) 
				{
					permissionCustomer.get(i).click();
				}
			}
	}
	
	public void clickOnPermissionProduct(String value) 
		{
			for (int i = 0; i < permissionProduct.size(); i++) 
			{
				if (permissionProduct.get(i).getText().equalsIgnoreCase(value))
				{
					permissionProduct.get(i).click();
				}
			}
		}
	
	public void clickOnPermissionPurchaseStock(String value) 
	{
		for (int i = 0; i < permissionPurchaseStock.size(); i++) 
		{
			if (permissionPurchaseStock.get(i).getText().equalsIgnoreCase(value))
			{
				permissionPurchaseStock.get(i).click();
			}
		}
	}
	
	public void clickOnPermissionSell(String value)
	{
		for (int i = 0; i < permissionSell.size(); i++)
		{
			if (permissionSell.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionSell.get(i).click();
			}
		}
	}
	
	public void clickOnPermissionBrand(String value) 
	{
		for (int i = 0; i < permissionBrand.size(); i++)
		{
			if (permissionBrand.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionBrand.get(i).click();
			}
		}
	}
	
	public void clickOnPermissionTaxRate(String value)
	{
		for (int i = 0; i < permissionTaxRate.size(); i++)
		{
			if (permissionTaxRate.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionTaxRate.get(i).click();
			}
		}
	}
	
		public void clickOnPermissionUnit(String value)
		{
			for (int i = 0; i < Unit.size(); i++)
			{
				if (Unit.get(i).getText().equalsIgnoreCase(value))
				{
					Unit.get(i).click();
				}
			}
		}
		
	public void clickOnPermissionCategory(String value) 
	{
		for (int i = 0; i < permissionCategory.size(); i++) 
		{
			if (permissionCategory.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionCategory.get(i).click();
			}
		}
	}
	
	public void clickOnPermissionReport(String value) 
	{
		for (int i = 0; i < permissionReport.size(); i++) 
		{
			if (permissionReport.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionReport.get(i).click();
			}
		}
	}
	
	public void clickOnPermissionSetting(String value)
	{
		for (int i = 0; i < permissionSetting.size(); i++)
		{
			if (permissionSetting.get(i).getText().equalsIgnoreCase(value)) 
			{
				permissionSetting.get(i).click();
			}
		}
	}
	
	
		public void clickOnPermissionAccount(String value)
		{
			for (int i = 0; i < permissionAccount.size(); i++) 
			{
				if (permissionAccount.get(i).getText().equalsIgnoreCase(value)) 
				{
					permissionAccount.get(i).click();
				}
			}
		}
		
		
		
		
		public void clickOnSave()
		{
			clickOnElement(saveButton);
		}

}
