package testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.democompany.automationcore.Base;
import com.democompany.pages.HomePage;
import com.democompany.pages.LoginPage;
import com.democompany.pages.RolesPage;
import com.democompany.pages.UserManagementPage;
import com.democompany.pages.UsersPage;

public class RolesTest extends Base
{
	LoginPage login;
	HomePage home;
	UserManagementPage mgmtpage;
	UsersPage userpage;
	RolesPage rolespage;
	
	@Test(enabled=true)
	public void verifyRolesPageTitle()
	{
	
	login=new LoginPage(driver);
	login.enterUsername("admin");
	login.enterPassword("123456");
	home=login.clickOnLoginButton();
	home.handleEndTour();
	mgmtpage=home.clickOnUserManagement();
	rolespage=mgmtpage.ClickOnRolesPage();
	rolespage.clickRoles();

	String actualuserPageTitle=driver.getTitle();
	String expecteduserPageTitle="Roles - Demo Company";
	Assert.assertEquals(actualuserPageTitle, expecteduserPageTitle,"Title Mismatch");
	}
	
	@Test(enabled=true)
	public void AddRoles()
	{
	login=new LoginPage(driver);
	login.enterUsername("admin");
	login.enterPassword("123456");
	home=login.clickOnLoginButton();
	home.handleEndTour();
	mgmtpage=home.clickOnUserManagement();
	rolespage=mgmtpage.ClickOnRolesPage();
	rolespage.clickRoles();
	rolespage.clickToAddRoles();
	}
}
