package testscripts;

import com.democompany.automationcore.Base;

public class LogoutTest extends Base
{
	
}
