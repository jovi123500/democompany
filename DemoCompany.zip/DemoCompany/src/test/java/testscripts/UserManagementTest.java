package testscripts;

import com.democompany.automationcore.Base;

public class UserManagementTest extends Base
{

}
