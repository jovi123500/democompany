package testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.democompany.automationcore.Base;
import com.democompany.pages.LoginPage;
import com.democompany.pages.ResetPasswordPage;

public class ResetPasswordTest extends Base
{
	LoginPage login;
	ResetPasswordPage reset;
	
	@Test(enabled=true)
	public void verifyErrorMessage()
	{
	login=new LoginPage(driver);
	reset=login.clickResetPassword();
	reset.enterEmailForRecovery("moncy@gmail.com");
	reset.clickSubmitEmail();
	String actualresult=reset.getTextOfErrorMessage();
	String expectedresult="We can't find a user with that e-mail address.";
	Assert.assertEquals(actualresult, expectedresult,"Wrong");
	}

}
