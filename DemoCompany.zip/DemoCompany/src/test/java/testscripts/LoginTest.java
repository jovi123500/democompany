package testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.democompany.automationcore.Base;
import com.democompany.pages.HomePage;
import com.democompany.pages.LoginPage;


public class LoginTest extends Base
{
	LoginPage login;
	HomePage home;
	
	@Test(priority=1)
	public void loginWithValidCredentials()
	{
		
		login=new LoginPage(driver);
		login.enterUsername("admin");
		login.enterPassword("123456");
		home=login.clickOnLoginButton();
		String actualresult=home.getUserName();
		String expectedresult="Welcome Aju,";
		Assert.assertEquals(actualresult, expectedresult,"Login with invalid Credentials");
	}
	
	//@Test(priority=2)
	public void loginWithInValidCredentials()
	{
		
		login=new LoginPage(driver);
		login.enterUsername("admin11");
		login.enterPassword("1234567");
		login.clickOnLoginButton();
		String actualPage=login.getLoginPageTitle();
		String expectedPage="Login - Demo POS";
		Assert.assertEquals(actualPage, expectedPage,"Wrong!!! Login with invalid Credentials!!");
	}
	
	//@Test(priority=3)
	public void verifyUILoginPageUsername()
	{
	login=new LoginPage(driver);
	String actualUserLabel=login.verifyUsernameLabel();
	String expectedUserLabel="Username";
	Assert.assertEquals(actualUserLabel, expectedUserLabel,"Mismatch!!");
	}
	
	//@Test(priority=4)
	public void verifyUILoginPagePassword()
	{
	login=new LoginPage(driver);
	String actualPasswordLabel=login.verifyPasswordLabel();
	String expectedPasswordLabel="Password";
	Assert.assertEquals(actualPasswordLabel, expectedPasswordLabel,"Mismatch!!");
	}
	
	//@Test(priority=5)
	public void verifyUILoginPageLoginButton()
	{
	login=new LoginPage(driver);
	String actualLoginButton=login.verifyLoginButton();
	String expectedLoginButton="Login";
	Assert.assertEquals(actualLoginButton, expectedLoginButton,"Mismatch!!");
	}
	
	//@Test(priority=6)
	public void verifyUILoginPagePasswordLink()
	{
	login=new LoginPage(driver);
	String actualPasswordLinkText=login.verifyForgetPasswordLink();
	String expectedPasswordLinkText="Forgot Your Password?";
	Assert.assertEquals(actualPasswordLinkText, expectedPasswordLinkText,"Mismatch!!");
	}
	
	//@Test(priority=7)
	public void veifyCheckboxNotClicked()
	{
	login=new LoginPage(driver);
	boolean result=login.checkclickCheckbox();
	Assert.assertTrue(result, "CheckBox Clicked!!");
	}
	
}
