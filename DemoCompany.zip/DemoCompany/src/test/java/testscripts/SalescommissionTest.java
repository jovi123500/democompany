package testscripts;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.democompany.automationcore.Base;
import com.democompany.pages.HomePage;
import com.democompany.pages.LoginPage;
import com.democompany.pages.SalescommissionPage;
import com.democompany.pages.UserManagementPage;
import com.democompany.pages.UsersPage;

public class SalescommissionTest extends Base 
{
	LoginPage login;
	HomePage home;
	UserManagementPage mgmtpage;
	UsersPage userpage;
	SalescommissionPage sales;
	
	//@Test(priority=1)
	public void verifyUserPageTitle()
	{
	
	login=new LoginPage(driver);
	login.enterUsername("admin");
	login.enterPassword("123456");
	home=login.clickOnLoginButton();
	home.handleEndTour();
	mgmtpage=home.clickOnUserManagement();
	
	sales=mgmtpage.clickOnSalesPage();	

	String actualuserPageTitle=driver.getTitle();
	String expecteduserPageTitle="Sales Commission Agents - Demo Company";
	Assert.assertEquals(actualuserPageTitle, expecteduserPageTitle,"Title Mismatch");
	}
	
	//@Test(priority=2)
	public void verifyIsSalesPageLoaded()
	{
		login=new LoginPage(driver);
		login.enterUsername("admin");
		login.enterPassword("123456");
		home=login.clickOnLoginButton();
		home.handleEndTour();
		mgmtpage=home.clickOnUserManagement();
		sales=mgmtpage.clickOnSalesPage();	
		boolean result=sales.issalespageload();
		Assert.assertTrue(result, "Sales Page is not Loaded");
		
	}
	
	//@Test(priority=3)
	public void verifyAddSales()
	{
		login=new LoginPage(driver);
		login.enterUsername("admin");
		login.enterPassword("123456");
		home=login.clickOnLoginButton();
		home.handleEndTour();
		mgmtpage=home.clickOnUserManagement();
		sales=mgmtpage.clickOnSalesPage();	
		sales.clickOnaddsalesbutton();
		sales.entersur("Mr");
		sales.enterFname("Moncy");
		sales.enterLname("jose");
		sales.enterEmail("mon@gmail.com");
		sales.enterContact("123456789");
		sales.enteraddress("pune");
		sales.enterCommission("0.1");
		sales.clickSave();
		
	}
	
	//@Test(priority=4)
	public void VerifyTableContent()
	{
		login=new LoginPage(driver);
		login.enterUsername("admin");
		login.enterPassword("123456");
		home=login.clickOnLoginButton();
		home.handleEndTour();
		mgmtpage=home.clickOnUserManagement();
		sales=mgmtpage.clickOnSalesPage();
		String actualResult=sales.checktable("Mr Moncy jose");
		String expectedResult="Mr Moncy jose";
		Assert.assertEquals(actualResult, expectedResult,"Element is not present");
		
	}
}
